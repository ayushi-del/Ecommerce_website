let x= async ()=>{
    let data = await fetch('http://makeup-api.herokuapp.com/api/v1/products.json?brand=maybelline')
    console.log(data);
    let finaldata= await data.json()
    console.log(finaldata);
    let body = document.body
    let section = document.createElement('section')
    section.className="sec"
    body.appendChild(section)
    finaldata.map((x)=>{

        section.innerHTML+=`<div class="cards">
            <img src="${x.image_link}" height="200px" width="200px">
                <p>${x.name}</p>
                <p>${x.price}</p>
                <p>${x.category}</p>
                <button id="addcart">Addcart</button>
        </div>`

    })
}
x()

function search() {
    let input = document.getElementById('searchbar').value
    let x = document.getElementsByClassName('cards');
     for (i = 0; i < x.length; i++) { 
        if (!x[i].innerHTML.toLowerCase().includes(input)) {
            x[i].style.display="none";
        }
        else {
            x[i].style.display="cards";                 
        }
    }
}

// let y=document.getElementById

let b = document.getElementById('btn1')
b.addEventListener('click', ()=>{
    window.open('http://127.0.0.1:5501/Java%20Script/Task/API%20Website/Blush/index.html')
})


let c = document.getElementById('btn2')
c.addEventListener('click', ()=>{
    window.open('http://127.0.0.1:5501/Java%20Script/Task/API%20Website/Mascara/index.html')
})

let d = document.getElementById('btn3')
d.addEventListener('click', ()=>{
    window.open('http://127.0.0.1:5501/Java%20Script/Task/API%20Website/Foundation/index.html')
})

let e = document.getElementById('btn4')
e.addEventListener('click', ()=>{
    window.open('http://127.0.0.1:5501/Java%20Script/Task/API%20Website/Eyeliner/index.html')
})

let f = document.getElementById('btn5')
f.addEventListener('click', ()=>{
    window.open('http://127.0.0.1:5501/Java%20Script/Task/API%20Website/Lipstick/index.html')
})


