let x = async ()=>
{
    let data  = await fetch('https://makeup-api.herokuapp.com/api/v1/products.json?product_type=blush')
    console.log(data);
    let finalData = await data.json()
    console.log(finalData);
    finalData.map((x)=>
    {
        let body = document.body
        let section = document.createElement('section')
        section.className = "sec"
        section.innerHTML +=`<div class = "cards">
        <img src = "${x.image_link}" height = "120px" width = "140px">
        <p>${x.brand}</p>
        <p>${x.name}</p>
        <p>${x.price}</p>
        <p>${x.product_type}</p>
        <p>${x.category}</p>
        <p>${x.tag_list}</p>
        <button id="addcart">Addcart</button>
        </div>`
        body.appendChild(section)
    }
    )
}
x()

function search() {
    let input = document.getElementById('searchbar').value
    let x = document.getElementsByClassName('cards')

    for(i = 0; i<x.length;i++)
    {
        if(!x[i].innerHTML.toLowerCase().includes(input))
        {
            x[i].style.display = "none";
        }
        else
        {
            x[i].style.display = "cards";
        }
    }
}